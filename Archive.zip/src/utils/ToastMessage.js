// import { toast } from "react-toastify";

// export const ToastMessage = (message) => {
//   if (typeof message !== "string") {
//     console.log("============ToastMessageError", JSON.stringify(message));
//   } else {
//     toast(message);
//   }
// };
